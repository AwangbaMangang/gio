<?php
header('Content-Type: application/json');
$title = isset($_GET['title']) ? urlencode($_GET['title']) : '';
$url = "https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext&titles=$title&format=json";
echo file_get_contents($url);
?>