# Wikipedia → Meetei Mayek Translator

A simple web app to translate English Wikipedia articles to Meetei Mayek in real-time (per paragraph), using PHP, HTML, AJAX, and MinT as the translation backend.

## Features

- Fetches Wikipedia articles via title.
- Splits text into paragraphs, each can be translated individually.
- Real-time translation via MinT .
- Meetei Mayek font support.

## Setup

1. **Requirements:** PHP 7+, a web server, MinT translation engine.
2. **Install [Noto Sans Meetei Mayek](https://fonts.google.com/specimen/Noto+Sans+Meetei+Mayek) font for best display.**
3. **Deploy all files to your PHP-capable server.**
4. **Edit `translate.php` to call the MinT translation engine (replace the stub with actual command/API).**
5. **Visit `index.html` in your browser, enter a Wikipedia article title, and start translating!**

## Integrating MinT

Replace the fake translation section in `translate.php`:
```php
$translated = shell_exec("mint_translate $cmd en mtei");