<?php
header('Content-Type: application/json');
$data = json_decode(file_get_contents("php://input"), true);
$text = $data['text'] ?? '';
if (!$text) {
    echo json_encode(['translated' => 'No text provided.']);
    exit;
}

// Replace this with actual MinT API/CLI call on your server.
// For demonstration, this just returns the input with a prefix.
$cmd = escapeshellarg($text);
// Example: $translated = shell_exec("mint_translate $cmd en mtei");
// For now, fake translation:
$translated = "[Meetei Mayek translation would appear here]\n" . $text;

echo json_encode(['translated' => $translated]);
?>