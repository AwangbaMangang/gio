document.getElementById('wikiForm').onsubmit = async function(e) {
  e.preventDefault();
  const title = document.getElementById('wikiTitle').value.trim();
  document.getElementById('paragraphs').innerHTML = 'Loading article...';
  const res = await fetch('fetch_wikipedia.php?title=' + encodeURIComponent(title));
  const data = await res.json();
  const pages = data.query.pages;
  let extract = '';
  for (const k in pages) extract = pages[k].extract;
  if (!extract || extract.trim().length < 10) {
    document.getElementById('paragraphs').innerHTML = 'No article found.';
    return;
  }
  const paras = extract.split('\n').filter(p=>p.trim().length>10);
  let html = '';
  paras.forEach((para, i) => {
    html += `<div class="para" id="eng-${i}">
      <div>${para}</div>
      <button onclick="translateParagraph(${i}, \`${para.replace(/`/g, '\\`')}\`)">Translate to Meetei Mayek</button>
      <div class="mayek" id="mayek-${i}"></div>
    </div>`;
  });
  document.getElementById('paragraphs').innerHTML = html;
};

async function translateParagraph(idx, text) {
  const output = document.getElementById('mayek-' + idx);
  output.innerText = 'Translating...';
  const res = await fetch('translate.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text })
  });
  const data = await res.json();
  output.innerText = data.translated || 'Translation failed.';
}